#Crie uma lista contendo seis frutas de sua escolha. Depois de ter a lista pronta,
#converta essa lista em uma tupla. Por fim, exiba o conteúdo da tupla resultante para verificar as frutas que foram armazenadas.

frutas = ["morango","banana","uva","mertilo","acerola"]

tupla_frutas = tuple(frutas)

print(f"as frutas armazenadas na tupla são: {tupla_frutas}")

